#include<stdio.h>
#include<string.h>
#define max 51
struct stack{
	char c[max];
	int top;
	}st1;
void push(char ch)
{
	st1.top++;
	st1.c[st1.top]=ch;
}
int isEmpty()
{
	if(st1.top==-1)
		return 1;
	return 0;
}
char pop()
{
	if(!isEmpty())
		return st1.c[st1.top--];
	return '\0';
}
char peep()
{
	if(!isEmpty())
		return st1.c[st1.top];
}
int isOperand(char ch)
{
    return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
}
int Prec(char ch)
{
    switch (ch)
    {
    case '+':
    case '-':
        return 1;
 
    case '*':
    case '/':
        return 2;
 
    case '^':
        return 3;
    }
    return -1;
}
void infix_postfix(char *exp,char *exp1)
{
	char temp;
	int i,j;
	for(i=0,j=-1;exp[i]!='\0';i++)
	{
		if(isOperand(exp[i]))
			exp1[++j]=exp[i];
		else if (exp[i]=='(')
			push(exp[i]);
		else if(exp[i]==')')
		{
			while (!isEmpty() && peep() != '(')
		        exp1[++j] = pop();
			    if (peep() != '(')
				{
					printf("Invalid Expression\n");
					exit(0);
				}            
			    else
				temp=pop();
		}
		else
		{
			while (!isEmpty() && Prec(exp[i]) <= Prec(peep()))
                	exp1[++j] = pop();
                	push(exp[i]);
                }
        }
        while (!isEmpty()&&peep() != '(')
        	exp1[++j] = pop();
	if(!isEmpty())
	{
		printf("Invalid Expression\n");
		exit(0);
	}
	else
        	exp1[i]='\0';  
}
void main()
{
	char exp[51],exp1[51];
	printf("Enter the given Expression:");
	gets(exp);
	if(strlen(exp)>51)
	{
		printf("The maximum length of expression is 50\n");
		exit(0);
	}
	infix_postfix(exp,exp1);
	printf("The postfix expression is:%s\n",exp1);
}
	
