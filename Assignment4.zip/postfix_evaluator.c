#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<math.h>
#define max 51
struct stack{
	long c[max];
	int top;
	}st1;
void push(long ch)
{
	st1.top++;
	st1.c[st1.top]=ch;
}
int isEmpty()
{
	if(st1.top==-1)
		return 1;
	return 0;
}
long pop()
{
	if(!isEmpty())
		return st1.c[st1.top--];
	return '\0';
}
long peep()
{
	if(!isEmpty())
		return st1.c[st1.top];
}
int isOperator(char ch)
{
	if((ch=='+')||(ch=='-')||(ch=='*')||(ch=='/')||(ch=='^'))
		return 1;
	return 0;
}
long postfix_evaluator(char* exp)
{
	long i,val1,val2,res;
	for (i = 0; exp[i]!='\0'; ++i)
	{
		if (isdigit(exp[i]))
            		push((int)(exp[i] - '0'));
		else if(isOperator(exp[i]))
		{
			if(!isEmpty())
				val1=pop();
			else
			{
				printf("Invalid Expression!!!!\n");
				exit(0);
			}
			if(!isEmpty())
				val2=pop();
			else
			{
				printf("Invalid Expression!!!!\n");
				exit(0);
			}
			switch(exp[i])
			{
				case '+':push(val2+val1);
					 break;
				case '-':push(val2-val1);
					 break;
				case '*':push(val2*val1);
					 break;
				case '/':push(val2/val1);
					 break;
				case '^':res=(long)(pow(val2,val1));
					 push(res);
					 break;
			}
		}
		else
		{
			printf("Invalid Expression!!!!\n");
			exit(0);
		}
	}
	if((st1.top)-1==-1)
		return pop();
	else
		{
			printf("Invalid Expression!!!!\n");
			exit(0);
		}
}
void main()
{
	st1.top=-1;
	char exp[51];
	long result;
	printf("Enter the given Expression:");
	gets(exp);
	if(strlen(exp)>51)
	{
		printf("The maximum length of expression is 50\n");
		exit(0);
	}
	result=postfix_evaluator(exp);
	printf("The resultant value is %d\n",result);
}
