#include<stdio.h>
void max_min(int n,int a[100],int *max,int *min)
{
	*max=a[0];
	*min=a[0];
	int i;
	for(i=0;i<n;i++)
	{
		if(a[i]>*max)
			*max=a[i];
		if(a[i]<*min)
			*min=a[i];
	}
}
void main()
{
	int i,a[100],max,min,n;
	printf("Enter the Number of elements in array(max. 100):");
	scanf("%d",&n);
	while(n<1||n>100)
	{
		printf("Number of Elements can be between 1 and 100");
		printf("Enter Again:");
		scanf("%d",&n);
	}
	printf("Enter Elements of Array:");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}	
	max_min(n,a,&max,&min);
	printf("The Array is:");
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\nThe maximum of these Elements is: %d",max);
	printf("\nThe minimum of these Elements is: %d\n",min);
}
