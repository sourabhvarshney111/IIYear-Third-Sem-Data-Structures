#include<stdio.h>
void second(int n,int a[100],int *second_max,int *second_min)
{
	int max=a[0];
	int min=a[0];
	*second_max=0;
	*second_min=32767;
	int i;
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			*second_max=max;
			max=a[i];
		}
		else if(a[i]<max&&a[i]>*second_max)
			*second_max=a[i];
		if(a[i]<min)
		{
			*second_min=min;
			min=a[i];
		}
		else if(a[i]>min&&a[i]<*second_min)
			*second_min=a[i];			
	}
}
void main()
{
	int i,a[100],second_max,second_min,n;
	printf("Enter the Number of elements in array(max. 100):");
	scanf("%d",&n);
	while(n<1||n>100)
	{
		printf("Number of Elements can be between 1 and 100");
		printf("Enter Again:");
		scanf("%d",&n);
	}
	printf("Enter Elements of Array:");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}	
	second(n,a,&second_max,&second_min);
	printf("The Array is:");
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\nThe second maximum of these Elements is: %d",second_max);
	printf("\nThe second minimum of these Elements is: %d\n",second_min);
}
