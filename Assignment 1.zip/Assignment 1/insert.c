#include<stdio.h>
void main()
{
	int pos,n,a[100],i,temp;
	printf("Enter the number of Elements in Array(Between 1 and 100):");
	scanf("%d",&n);
	while(n<1&&n>100)
	{
		printf("Number of Elements can be between 1 and 100)!!! Enter Again:");
		scanf("%d",&n);
	}
	printf("Enter the Elements of Array:");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("The array now is:");
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");
	char ans='y';
	while(ans=='y'||ans=='Y')
	{
		if(n+1>100)
		{
			printf("Overflow!!!! Cannot Insert any Element");
			break;
		}
		else
		{
			printf("Enter the position to insert:");
			scanf("%d",&pos);
			if(pos<1||pos>n+1)
			{
				printf("Position Of insertion must be between 1 and %d",n+1);
				break;
			}
			else
			{
				printf("Enter the Element to insert:");
				scanf("%d",&temp);
				n+=1;
				for(i=n-1;i>=pos;i--)
					a[i]=a[i-1];
				a[pos-1]=temp;
			}
		}
		printf("Want to insert more Elements(y/n):");
		scanf("%c",&ans);
		scanf("%c",&ans);
	}
	printf("The array now is:");
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");
}
