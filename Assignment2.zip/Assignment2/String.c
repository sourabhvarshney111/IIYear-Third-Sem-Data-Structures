#include <stdio.h>
#include "STRING.h"
void main()
{
	char str[100],str1[200],*str2;
	long temp,temp1,ch;
	char c;
	printf("Enter the string to work upon:");
	gets(str);
	printf("\t\t\t\tString Manipulation Menu:\n");
	printf("\t\t\t\t1.Length of the string\n");
	printf("\t\t\t\t2.Concatenation of two different strings\n");
	printf("\t\t\t\t3.Retrieve the first index/position/occurrence of given symbol in the string\n");
	printf("\t\t\t\t4.Retrieve the last occurrence of given symbol in the string\n");
	printf("\t\t\t\t5.Concatenate the reversal of string at the end\n");
	printf("\t\t\t\t6.Duplicate and concate the main string\n");
	printf("\t\t\t\t7.Compare Strings\n");
	printf("\t\t\t\t8.Compare Strings without case sensitivity\n");
	printf("\t\t\t\t9.Reverse of the given string\n");
	printf("\t\t\t\t10.Convert the string to upper case\n");
	printf("\t\t\t\t11.Convert the string to lower case\n");
	printf("\t\t\t\t12.Convert the string to Title Case\n");
	printf("\t\t\t\t13.Replace the given substring in the main string from the given position\n");
	printf("\t\t\t\t14.Retrieve the index of the substring in the main string\n");
	printf("\t\t\t\t15.Check the given string is palindrome or not\n");
	printf("\t\t\t\t16.Display and count the vowels present in the string\n");
	printf("\t\t\t\t17.Count the characters and words\n");
	printf("\t\t\t\tEnter corresponding number of your choice:");
	scanf("%ld",&ch);
	switch(ch)
	{
		case 1:	temp=str_len(str);
			printf("The length of the string is %ld\n",temp);
			break;
		case 2:	printf("Enter the second string:");
			gets(str1);
			gets(str1);
			str2=str_cat(str,str1);
			printf("The concatenated string is:");
			puts(str2);
			break;
		case 3: printf("Enter the character to searched:");
			scanf("%c",&c);
			scanf("%c",&c);
			temp=first_index(str,c);
			if(temp==-1)
				printf("Character not found\n");
			else
				printf("The first occurence is at %ld position\n",temp);
			break;
		case 4: printf("Enter the character to searched:");
			scanf("%c",&c);
			scanf("%c",&c);
			temp=last_index(str,c);
			if(temp==-1)
				printf("Character not found\n");
			else
				printf("The last occurence is at %ld position\n",temp);
			break;
		case 5: str2=rev_cat(str);
			printf("The output string is:");
			puts(str2);
			break;
		case 6:	str2=dup_cat(str);
			printf("The output string is:");
			puts(str2);
			break;
		case 7:	printf("Enter the string to be compared with the first string:");
			gets(str1);
			gets(str1);
			temp=str_comp(str,str1);
			if(temp)
				printf("Strings are same\n");
			else
				printf("Strings are different\n");
			break;
		case 8:	printf("Enter the string to be compared with the first string:");
			gets(str1);
			gets(str1);
			temp=str_case_comp(str,str1);
			if(temp)
				printf("Strings are same without case senstivity\n");
			else
				printf("Strings are different without case senstivity\n");
			break;
		case 9:	str2=rev(str);
			printf("The reverse of the string is:");
			puts(str2);
			break;
		case 10:to_up_string(str);
			printf("The output string is:");
			puts(str);
			break;
		case 11:to_low_string(str);
			printf("The output string is:");
			puts(str);
			break;
		case 12:to_title(str);
			printf("The output string is:");
			puts(str);
			break;
		case 13:printf("Enter the position of the substring to be replaced:");
			scanf("%ld",&temp);
			printf("Enter the new substring:");
			gets(str1);
			gets(str1);
			repl_sub(str,str1,temp);
			printf("The output string is:");
			puts(str);
			break;
		case 14:printf("Enter the substring:");
			gets(str1);
			gets(str1);
			temp=sub_index(str,str1);
			if(temp==-1)
				printf("Substring not found\n");
			else
				printf("The substring found at %ld position\n",temp);
			break;
		case 15:temp=check_palindrome(str);
			if(temp)
				printf("String is Pallindrome\n");
			else
				printf("String is not Pallindrome\n");
			break;
		case 16:temp=count_vowels(str);
			printf("The number of vowels in %s is %ld\n",str,temp);
			break;
		case 17:temp=count(str,&temp1);
			printf("The number of characters in %s is %ld\n",str,temp);
			printf("The number of words in %s is %ld\n",str,temp1);
			break;
		default: printf("Wrong Choice!!!\n");
			 break;
	}
}
