#include<ctype.h>
long str_len(char *str)
{
	long i;
	for(i=0;str[i]!='\0';i++);
	return i;
}
char * str_cat(char *str1,char *str2)
{
	char *str3=(char*)malloc(sizeof(char)*300);
	long i,j=0;
	for(i=0;str1[i]!='\0';i++,j++)
		str3[j]=str1[i];
	for(i=0;str2[i]!='\0';i++,j++)
		str3[j]=str2[i];
	str3[j]='\0';
	return str3;
}
long first_index(char *str,char c)
{
	long i;
	for(i=0;str[i]!='\0';i++)
		if(str[i]==c)
			return i+1;
	return -1;
}
long last_index(char *str,char c)
{
	long i=str_len(str);
	for(i-=1;i>=0;i--)
		if(str[i]==c)
			return i+1;
	return -1;
}
char * rev(char *str)
{
	long n=str_len(str),i;
	char *str1=(char*)malloc(sizeof(char)*100);
	for(i=0;i<n;i++)
		str1[i]=str[n-i-1];
	str1[n]='\0';
	return str1;
}
char * rev_cat(char *str)
{
	char *str1;
	str1=rev(str);
	str1=str_cat(str,str1);
	return str1;
}
char * dup_cat(char *str)
{
	char *str1=(char*)malloc(sizeof(char)*200);
	long i;
	for(i=0;str[i]!='\0';i++)
		str1[i]=str[i];
	str1[i]='\0';
	str1=str_cat(str,str1);
	return str1;
}
int str_comp(char *str,char *str1)
{
	long i;
	for(i=0;str[i]!='\0' && str1[i]!='\0';i++)
		if(str[i]!=str1[i])
			break;
	if(str[i]=='\0' && str1[i]=='\0')
		return 1;
	return 0;
}
int str_case_comp(char *str,char *str1)
{
	long i;
	for(i=0;str[i]!='\0'&&str1[i]!='\0';i++)
		if(tolower(str[i])!=tolower(str1[i]))
			break;
	if(str[i]=='\0'&&str1[i]=='\0')
		return 1;
	return 0;
}
void to_low_string(char *str)
{
	long i;
	for(i=0;str[i]!='\0';i++)
		str[i]=tolower(str[i]);
}
void to_up_string(char *str)
{
	long i;
	for(i=0;str[i]!='\0';i++)
		str[i]=toupper(str[i]);
}
void to_title(char *str)
{
	long i;
	str[0]=toupper(str[0]);
	for(i=1;str[i]!='\0';i++)
		if(str[i]==' ' && str[i+1]!=' ')
			str[i+1]=toupper(str[i+1]);
}
void repl_sub(char *str,char *sub1,long pos)
{
	long i,j,k;
	i=str_len(str);
	j=str_len(sub1);
	if(pos<0||pos+j-1>i)
	{
		printf("Invalid Position\n");
		exit(1);
	}
	else
	{
		for(i=pos-1,k=0;str[i]!='\0' && sub1[k]!='\0';i++,k++)
			str[i]=sub1[k];
	}	
}
long sub_index(char *str,char *sub1)
{
	long i,j,k;
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==sub1[0])
		{
			j=0;
			k=i;
			while(str[++k]==sub1[++j]);
			if(sub1[j]=='\0')
				return i+1;
		}
	}
	return -1;
}
long check_palindrome(char *str)
{
	char *str1=rev(str);
	return str_comp(str1,str);	
}
long count_vowels(char *str)
{
	long i,count=0;
	for(i=0;str[i]!='\0';i++)
		if(tolower(str[i])=='a'||tolower(str[i])=='e'||tolower(str[i])=='i'||tolower(str[i])=='o'||tolower(str[i])=='u')
			count++;
	return count;
}
long count(char *str,long *word_count)
{
	*word_count=1;
	long i;
	for(i=0;str[i]!='\0';i++)
		if(str[i]==' ' && str[i+1]!=' ')
			(*word_count)++;
	return i;
}
