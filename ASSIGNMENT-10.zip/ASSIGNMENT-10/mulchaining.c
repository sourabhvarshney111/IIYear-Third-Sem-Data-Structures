#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* next;
};

struct block
{
	int number;
	struct node* head;
};

struct block arr[8];

void insert(void);
struct node* newnode(void);
void search(void);
void display (void);

int main()
{
	printf("This is an example of multiplicative hashing function using chaining technique.\n\n");
	printf("In this function we have used a array of size 8.\n\n");
	int i;
	for(i=0;i<8;i++)
	{
		arr[i].number=-1;
		arr[i].head=NULL;
	}
	printf("------------------------------------------------------------------------------\n");
	while(1)
	{
		printf("Enter 1 for insertion\nEnter 2 for search\nEnter 3 for display\nEnter 4 for exit.\n");
		printf("Enter your choice.\n\n");
		scanf("%d",&i);
		if(i==4)
		{
			break;
		}
		switch(i)
		{
			case 1:
				insert();
				break;
				
			case 2:
				search();
				break;
				
			case 3:
				display();
				break;
				
			default:
				printf("Error in input.\n");
				break;			
		}
		printf("------------------------------------------------------------------------\n");
	}
	getch();
	return 0;
}

void insert(void)
{
	int j,b;
	float d;
	printf("Enter Number to be inserted...\n");
	scanf("%d",&j);
	d=0.7;
	b=j*d;
	d=j*d-b;
	d=8*d;
	b=d;
	printf("%d is stored at index %d.\n\n",j,b);
	if(arr[b].number==-1)
	{
		arr[b].number=j;
		return;
	}
	struct node *temp1,*temp=newnode();
	temp->data=j;
	if(arr[b].head==NULL)
	{
		arr[b].head=temp;
		return;
	}
	temp1=arr[b].head;
	while(temp1->next!=NULL)
	{
		temp1=temp1->next;
	}
	temp1->next=temp;
}

struct node* newnode(void)
{
	struct node *n;
	n = (struct node*)malloc(sizeof(struct node));
	n->next=NULL;
	return n;
}

void search(void)
{
	int j,b;
	float d;
	printf("Enter number to be searched.\n");
	scanf("%d",&j);
	d=0.7;
	b=j*d;
	d=j*d-b;
	d=8*d;
	b=d;
	if(arr[b].number==j)
	{
		printf("%d found at index %d.\n\n",j,b);
		return;
	}
	if(arr[b].number==-1||arr[b].head==NULL)
	{
		printf("%d not found.\n\n",j);
		return;
	}
	struct node* temp=arr[b].head;
	while(temp!=NULL)
	{
		if(temp->data==j)
		{
			printf("%d found at index %d.\n\n",j,b);
			return;
		}
		temp=temp->next;
	}
	printf("%d not found.\n\n",j);
}

void display (void)
{
	printf("\n");
	int i;
	struct node* temp;
	for(i=0;i<8;i++)
	{
		printf("INDEX %d : ",i);
		if(arr[i].number==-1)
		{
			printf("\n");
			continue;
		}
		printf("%d ",arr[i].number);
		temp=arr[i].head;
		while(temp!=NULL)
		{
			printf("%d ",temp->data);
			temp=temp->next;
		}
		printf("\n");
	}
}
