#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

long int arr[100];

void insert(void);
void del(void);
void search(void);
void display (void);

int main()
{
	printf("This is an example of folding hashing function using linear probing technique.\n\n");
	printf("In this function we have used a array of size 100.\n\n");
	int i;
	for(i=0;i<100;i++)
	{
		arr[i]=-1;
	}
	printf("-------------------------------------------------------------------------\n");
	while(1)
	{
		printf("Enter 1 for insertion\nEnter 2 for search\nEnter 3 for Deletion\nEnter 4 for display\nEnter 5 for exit.\n");
		printf("Enter your choice.\n\n");
		scanf("%d",&i);
		if(i==5)
		{
			break;
		}
		switch(i)
		{
			case 1:
				insert();
				break;
				
			case 2:
				search();
				break;
				
			case 3:
				del();
				break;	
				
			case 4:
				display();
				break;
				
			default:
				printf("Error in input.\n");
				break;			
		}
		printf("----------------------------------------------------------------------------\n");
	}
	getch();
	return 0;
}

void insert(void)
{
	char c[8];
	int a,b=0,d,i=0;
	long int j;
	printf("Enter Number to be inserted...\n");
	scanf("%s",c);
	j=atoi(c);
	while(c[i]!='\0'&&c[i+1]!='\0')
	{
		a=c[i]-48;
		d=c[i+1]-48;
		b=b+10*a+d;
		i=i+2;
	}
	if(c[i]!='\0')
	{
		a=c[i]-48;
	}
	else
	{
		a=0;
	}
	b=b+a;
	b=b%100;
	if(arr[b]==-1)
	{
		printf("%ld is stored at index %d.\n\n",j,b);
		arr[b]=j;
		return;
	}
	a=(b+1)%100;
	while(a!=b)
	{
		if(arr[a]==-1)
		{
			printf("%d is stored at index %d.\n\n",j,a);
			arr[a]=j;
			return;
		}
		a=(a+1)%100;
	}
	printf("OVERFLOW.\n");
}

void search(void)
{
	char c[8];
	int a,b=0,d,i=0;
	long int j;
	printf("Enter Number to be searched...\n");
	scanf("%s",c);
	j=atoi(c);
	while(c[i]!='\0'&&c[i+1]!='\0')
	{
		a=c[i]-48;
		d=c[i+1]-48;
		b=b+10*a+d;
		i=i+2;
	}
	if(c[i]!='\0')
	{
		a=c[i]-48;
	}
	else
	{
		a=0;
	}
	b=b+a;
	b=b%100;
	if(arr[b]==j)
	{
		printf("%ld found at index %d.\n\n",j,b);
		return;
	}
	a=(b+1)%100;
	while(a!=b)
	{
		if(arr[a]==j)
		{
			printf("%d found at index %d.\n\n",j,a);
			return;
		}
		a=(a+1)%100;
	}
	printf("%d not found.\n",j);
}

void display (void)
{
	printf("\n");
	int i;
	for(i=0;i<100;i++)
	{
		if(arr[i]==-1)
		{
			continue;
		}
		printf("INDEX %d : ",i);
		printf("%ld ",arr[i]);
		printf("\n");
	}
}

void del(void)
{
	char c[8];
	int a,b=0,d,i=0;
	long int j;
	printf("Enter Number to be deleted...\n");
	scanf("%s",c);
	j=atoi(c);
	while(c[i]!='\0'&&c[i+1]!='\0')
	{
		a=c[i]-48;
		d=c[i+1]-48;
		b=b+10*a+d;
		i=i+2;
	}
	if(c[i]!='\0')
	{
		a=c[i]-48;
	}
	else
	{
		a=0;
	}
	b=b+a;
	b=b%100;
	if(arr[b]==j)
	{
		printf("%ld deleted at index %d.\n\n",j,b);
		arr[b]=-1;
		return;
	}
	a=(b+1)%100;
	while(a!=b)
	{
		if(arr[a]==j)
		{
			printf("%d deleted at index %d.\n\n",j,a);
			arr[a]=-1;
			return;
		}
		a=(a+1)%100;
	}
	printf("%d not found\n",j);
}
