#include<stdio.h>
#include<stdlib.h>

struct info
{
	char name[80];
	char roll[9];
	float cgpa;
	struct info *next;
};
void insertroll(void);
struct info *newnode(void);
void deletefirst(void);
void deletelast(void);
void deletebtw(void);
void search(int i);
int compare(char a[],char b[]);
void display(void);
int count(void);

struct info *head;

int main()
{
	head=NULL;
	printf("This program creates a linear ordered linked list.\n\n");
	printf("------------------------------------------------------------\n");
	int i,j;
	while(1)
	{
		printf("Enter 1 for Insertion\nEnter 2 for Deletion\nEnter 3 for Search\nEnter 4 for Display\nEnter 5 for exit.\n\n");
		scanf("%d",&i);
		if(i==5)
		{
			return 0;
		}
		switch(i)
		{
			case 1: insertroll();
				break;
						
			case 2:
			if(head==NULL)
			{
				printf("List Empty.\nNo deletion is possible.\n");
				break;
			}
			printf("Enter 1 for deletion at first node\nEnter 2 for deletion at last node\nEnter 3 for deletion in between node.\n\n");
			scanf("%d",&j);
			switch(j)
			{
				case 1:
				deletefirst();
				break;
					
				case 2:
				deletelast();
				break;
						
				case 3:
				deletebtw();
				break;
						
				default:
				printf("Error in input.\n");
				break;			
			}
			break;
			
			case 3:
			if(head==NULL)
			{
				printf("List Empty.\nNo search is possible.\n");
				break;
			}
			printf("Enter 1 for search by name\nEnter 2 for search by roll number\nEnter 3 for search by cgpa.\n");
			scanf("%d",&i);
			if(i<1||i>3)
			{
				printf("Error in input.\n");
			}	
			else
			{
				search(i);
			}
			break;
				
			case 4:
			display();
			break;
			case 5: exit(0);
					
			default :
			printf("Wrong input.\n");
			break;
		}
		printf("------------------------------------------------------------\n");
	}	
	getch();
	return 0;
}

struct info *newnode(void)
{
	struct info *n=(struct info*)malloc(sizeof(struct info));
	printf("Enter Name.\n");
	char a[40];
	gets(a);
	gets(n->name);
	printf("Enter Roll number.\n");
	gets(n->roll);
	printf("Enter cgpa.\n");
	scanf("%f",&n->cgpa);
	n->next=NULL;
	return n;
}

void insertroll(void)
{
	struct info *temp,*temp1,*temp2;
	temp=newnode();
	if(head==NULL)
	{
		head=temp;
		return;
	}
	temp1=head;
	if(compare(temp->roll,temp1->roll)<0)
	{
		head=temp;
		temp->next=temp1;
		return;
	}
	while(compare(temp->roll,temp1->roll)>0&&temp1->next!=NULL)
	{
		temp2=temp1;
		temp1=temp1->next;
	}
		if(temp1->next==NULL)
		{
			if(compare(temp->roll,temp1->roll)>0)
			{
				temp1->next=temp;
				return;
			}
			temp2->next=temp;
			temp->next=temp1;
			return;
		}
	temp2->next=temp;
	temp->next=temp1;
	return;
}

void deletefirst(void)
{
	if(head==NULL)
	{
		printf("\nLIST EMPTY.\nNO DELETION IS POSSIBLE.\n");
		return;
	}
	struct info *temp;
	temp=head;
	head=head->next;
	printf("\nThe entry deleted is -\n");
	printf("\nNAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp->name,temp->roll,temp->cgpa);
	free(temp);
}

void deletelast(void)
{
	if(head==NULL)
	{
		printf("\nLIST EMPTY.\nNO DELETION IS POSSIBLE.\n");
		return;
	}
	struct info *temp,*temp1;
	temp=head;
	if(temp->next==NULL)
	{
		head=NULL;
		printf("\nThe entry deleted is -\n");
		printf("\nNAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp->name,temp->roll,temp->cgpa);
		free(temp);
		return;
	}
	while(temp->next->next!=NULL)
	{
		temp=temp->next;
	}
	temp1=temp->next;
	temp->next=NULL; 
	printf("\nThe entry deleted is -\n");
	printf("\nNAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp1->name,temp1->roll,temp1->cgpa);
	free(temp1);
}

void deletebtw(void)
{
	if(head==NULL)
	{
		printf("\nLIST EMPTY.\nNO DELETION IS POSSIBLE.\n");
		return;
	}
	struct info *temp,*temp1,*temp2;
	int i,j;
	printf("Enter the position at which the node is to be deleted.\n");
	scanf("%d",&i);
	if(i==1)
	{
		temp=head;
		head=temp->next;
		printf("\nThe entry deleted is -\n");
		printf("\nNAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp->name,temp->roll,temp->cgpa);
		free(temp);
		return;
	}
	if(i>count())
	{
		printf("\nINVALID POSITION.\n");
		return;
	}
	temp=head;
	for(j=1;j<=i-2;j++)
	{
		temp=temp->next;
	}
	temp1=temp->next;
	temp2=temp1->next;
	temp->next=temp2;
	printf("\nThe entry deleted is -\n");
	printf("\nNAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp1->name,temp1->roll,temp1->cgpa);
	free(temp1);
}

void search(int i)
{
	struct info *temp;
	float b;
	char a[20];
	temp=head;
	int j,k=0;
	switch(i)
	{
		case 1:
			printf("Enter Name to be searched.\n");
			scanf("%s",a);
			while(temp!=NULL)
			{
				k++;
				j=compare(a,temp->name);
				if(j==0)
				{
					printf("\nNAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp->name,temp->roll,temp->cgpa);
					printf("Found at position = %d\n",k);
					return;
				}
				temp=temp->next;
			}
			printf("\nGiven name not found.\n");
			break;
			
			case 2:
			printf("Enter ROLL NUMBER to be searched.\n");
			scanf("%s",a);
			while(temp!=NULL)
			{
				k++;
				j=compare(a,temp->roll);
				if(j==0)
				{
					printf("\nNAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp->name,temp->roll,temp->cgpa);
					printf("Found at position = %d\n",k);
					return;
				}
				temp=temp->next;
			}
			printf("\nGiven roll number not found.\n");
			break;	
			
			case 3:
			printf("Enter CGPA to be searched.\n");
			scanf("%f",&b);
			while(temp!=NULL)
			{
				k++;
				if(b==temp->cgpa)
				{
					printf("NAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n",temp->name,temp->roll,temp->cgpa);
					printf("Found at position = %d\n",k);
					return;
				}
				temp=temp->next;
			}
			printf("\nGiven CGPA not found.\n");
			break;
	}
}

int compare(char a[],char b[])
{
	int i,m;
	for(i=0;(a[i]!='\0')&&(b[i]!='\0');i++)
	{
		m=a[i]-b[i];
		if(m!=0)
		{
			return m;
		}
	}
	if((a[i]=='\0')&&(b[i]=='\0'))
	{
		return 0;
	}
	else
	{
		m=a[i]-b[i];
		return m;
	}
}

void display(void)
{
	if(head==NULL)
	{
		printf("LIST EMPTY.\n");
		return;	
	}	
	struct info *temp=head;
	printf("The list is -\n");
	while(temp!=NULL)
	{
		printf("NAME       : %s\nROLL NUMBER: %s\nCGPA       : %.2f\n\n",temp->name,temp->roll,temp->cgpa);
        temp=temp->next;
	}
} 

int count(void)
{
	struct info *temp;
	int i=0;
	temp=head;
	while(temp!=NULL)
	{
		i++;
		temp=temp->next;
	}
	return i;
}
