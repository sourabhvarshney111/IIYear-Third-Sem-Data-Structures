#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	char data;
	struct node *l;
	struct node *r;
}*root,*temp;

struct node *getnode(char d)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=d;
	temp->l=NULL;
	temp->r=NULL;
	return temp;
}


int hgt(struct node *node)
{
	if(node==NULL)
	{
		return 0;
	}
	if((hgt(node->l))>(hgt(node->r)))
	{
		return 1+hgt(node->l);
	}
	else
	{
		return 1+hgt(node->r);
	}
}



struct node *create(struct node *node,char c)
{
	if(node==NULL)
	{
		return getnode(c);
	}
	if(c<node->data)
	{
		node->l=create(node->l,c);
	}
	else if(c>node->data)
	{
		node->r=create(node->r,c);
	}
	return node;
}


int main()
{
	int no,i,cont,height,temp;
	char a[100];
	printf("Enter number of nodes(Max. 100)\n");
	scanf("%d",&no);
	if(no>0)
	{
		printf("Enter the nodes:");
		scanf("%c",&a[0]);
		root=create(root,a[0]);
		for(i=1;i<no;i++)
		{
			scanf("%c",&a[i]);
			temp=create(root,a[i]);
		}
		 height=hgt(root);
		 printf("Depth of tree :  %d\n\n",height);
	}
	else
		printf("A no node tree cannot be created\n");
}
