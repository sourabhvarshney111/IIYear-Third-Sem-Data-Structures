#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	char data;
	struct node *l;
	struct node *r;
}*root,*temp;

struct node *getnode(char d)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=d;
	temp->l=NULL;
	temp->r=NULL;
	return temp;
}

void inorder(struct node *node)
{
	if(node!=NULL)
	{
		inorder(node->l);
		printf("%c   ",node->data);
		inorder(node->r);
	}
}

void delet(struct node *node,char x)
{
	int found=0,d=0;
	struct node *cur=root,*parent=root;
	while(found==0&&cur!=NULL)
	{
		if(cur->data==x)
		{
			found=1;
		}
		else
		{
			if(x<cur->data)
			{
				parent=cur;
				cur=cur->l;
				d=0;
			}
			else
			{
				parent=cur;
				cur=cur->r;
				d=1;	
			}
		}
	}
	if(found==0)
	{
		printf("\nnot found.. :(\n");
		return false;
	}
	struct node *u,*s,*p;
	if(cur->l==NULL)
	{
		u=cur->r;
	}
	else if(cur->r==NULL)
	{
		u=cur->l;
	}
	else
	{
		s=cur->r;
		if(s->l==NULL)
		{
			s->l=cur->l;
			u=s;
		}
		else
		{
			p=cur->r;
			s=p->l;
			while(s->l!=NULL)
			{
				p=s;
				s=p->l;
			}
			p->l=s->r;
			s->l=cur->l;
			s->r=cur->r;
			u=s;
		}
	}
	if(d==0)
	{
		parent->l=u;
	}
	else
	{
		parent->r=u;
	}

}

struct node *create(struct node *node,char c)
{
	if(node==NULL)
	{
		return getnode(c);
	}
	if(c<node->data)
	{
		node->l=create(node->l,c);
	}
	else if(c>node->data)
	{
		node->r=create(node->r,c);
	}
	return node;
}


int main()
{
	int no,i,cont,height;
	char a[100],del;
	printf("enter number of node....\n");
	scanf("%d",&no);
	while(no<=0)
	{
		printf("Number of nodes needs to be positive integer\n");
	}
	for(i=0;i<no;i++)
	{
		scanf("%c",&a[i]);
	}
	root=create(root,a[0]);
	for(i=1;i<no;i++)
	{
		temp=create(root,a[i]);
	}
	printf("\nInorder sequence:\n");
	inorder(root);
	printf("\n\nEnter the node to be deleted..\n");
	scanf("%c",&del);
	delet(root,del);
	printf("\nInorder sequence:\n");
	inorder(root);
}
