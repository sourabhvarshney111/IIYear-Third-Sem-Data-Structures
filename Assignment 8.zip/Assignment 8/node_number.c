#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	char data;
	struct node *l;
	struct node *r;
}*root,*temp;

struct node *getnode(char d)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=d;
	temp->l=NULL;
	temp->r=NULL;
	return temp;
}
void inorder(struct node *node)
{
	if(node!=NULL)
	{
		inorder(node->l);
		printf("%c   ",node->data);
		inorder(node->r);
	}
}



int node_no(struct node *node,int count)
{ 
	if(node->l!=NULL)
	{
		count++;
		count=node_no(node->l,count);
	}
	if(node->r!=NULL)
	{
		count++;
		count=node_no(node->r,count);
	}
	return count;
}



struct node *create(struct node *node,char c)
{
	if(node==NULL)
	{
		return getnode(c);
	}
	if(c<node->data)
	{
		node->l=create(node->l,c);
	}
	else if(c>node->data)
	{
		node->r=create(node->r,c);
	}
	return node;
}


int main()
{
	int no,i,cont,height;
	char a[100];
	printf("Enter number of node to be inserted in the tree....\n");
	scanf("%d",&no);
	if(no>0)
	{
		for(i=0;i<no;i++)
		{
			scanf("%c",&a[i]);
		}
		root=create(root,a[0]);
		for(i=1;i<no;i++)
		{
			temp=create(root,a[i]);
		}
		printf("Inorder sequence is:");
		inorder(root);
		cont=node_no(root,0);
		printf("\nno of node:%d\n\n",cont+1);
	}
	else
		printf("Number of nodes in tree cannot be less than or equal to zero\n");
}
