#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	int data;
	struct node *l;
	struct node *r;
}*root;

struct node *getnode(int d)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=d;
	temp->l=NULL;
	temp->r=NULL;
	return temp;
}


char maximum(struct node *node)
{
	while(node->r!=NULL)
	{
		node=node->r;
	}
	return node->data;
}

void inorder(struct node *node)
{
	if(node!=NULL)
	{
		inorder(node->l);
		printf("%c   ",node->data);
		inorder(node->r);
	}
}



char minimum(struct node *node)
{
	while(node->l!=NULL)
	{
		node=node->l;
	}
	return node->data;
}



struct node *create(struct node *node,char c)
{
	if(node==NULL)
	{
		return getnode(c);
	}
	if(c<node->data)
	{
		node->l=create(node->l,c);
	}
	else if(c>node->data)
	{
		node->r=create(node->r,c);
	}
	return node;
}


int main()
{
	int no,i,cont,height;
	char a[100];
	printf("Enter number of node....\n");
	scanf("%d",&no);
	if(no>0)
	{
		for(i=0;i<no;i++)
		{
			scanf("%d",&a[i]);
		}
		root=create(root,a[0]);
		for(i=1;i<no;i++)
		{
			temp=create(root,a[i]);
		}
		printf("Inoder sequence is:\n");
		inorder(root);
		printf("\n");
		char max=maximum(root);
		char min=minimum(root);
		printf("maximum: %c\n",max);
		printf("minimum: %c\n",min);
	}
	else
	{
		printf("Number of nodes must be positive integer\n");
	}
}
