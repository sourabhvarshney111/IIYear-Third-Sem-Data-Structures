#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	int data;
	struct node *l;
	struct node *r;
}*root,*temp;

int flag=0;

struct node *getnode(char d)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=d;
	temp->l=NULL;
	temp->r=NULL;
	return temp;
}


void postorder(struct node *node)
{
	if(node!=NULL)
	{
		postorder(node->l);
		postorder(node->r);
		printf("%d   ",node->data);
	}
}

void inorder(struct node *node)
{
	if(node!=NULL)
	{
		inorder(node->l);
		printf("%d   ",node->data);
		inorder(node->r);
	}
}


void preorder(struct node *node)
{
	if(node!=NULL)
	{
		printf("%d   ",node->data);
		preorder(node->l);
		preorder(node->r);
		
	}
}


struct node *search(struct node *node,int d)
{
	
	if(node!=NULL)
	{
		if(d==node->data)
		{
			printf("\nData Found");
			flag=1;
		}
		else
		{
			search(node->l,d);
			search(node->r,d);
		}
	}

}
struct node *create(struct node *node,int c)
{
	if(node==NULL)
	{
		return getnode(c);
	}
	if(c<node->data)
	{
		node->l=create(node->l,c);
	}
	else if(c>node->data)
	{
		node->r=create(node->r,c);
	}
	return node;
}

int main()
{
	root=NULL;
	int ch,z=1,i,n;
	int a[100],sear;
	while(z)
	{
		printf("\n1.Create tree\n2.Search data in tree\n3.Preorder seqence\n4.Postorder sequence\n5.Inorder squence\n6.exit\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("Enter number of nodes\n");
				scanf("%d",&n);
				if(n>0)
				{
					for(i=0;i<n;i++)
					{
						scanf("%d",&a[i]);
					}
					root=create(root,a[0]);
					for(i=1;i<n;i++)
					{
						temp=create(root,a[i]);
					}
					break;
				}	
				else
					printf("Number of nodes in a tree cannot be less than or equal to zero");
			case 2:
				printf("\nEnter search data...\n");
				scanf("%d",&sear);
				flag=0;
				search(root,sear);
				if(flag==0)
					printf("Data not available\n");
				break;
			case 3:
				printf("\nPreorder traversal sequence:\n");
				preorder(root);
				printf("\n\n");
				break;
			case 4:
				printf("\nInorder traversal sequence:\n");
				inorder(root);
				printf("\n\n");
				break;
			case 5:
				printf("\nPostorder traversal sequence:\n");
				postorder(root);
				printf("\n\n");
				break;
			case 6:
				z=0;
				break;
			default:
				printf("\nEnter correct choice...\n");
				break;
		}
	}
	return 0;
}
