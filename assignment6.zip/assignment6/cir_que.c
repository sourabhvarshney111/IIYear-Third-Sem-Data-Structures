#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAX 10
struct plane{
	char id[20];
	char name[80];
	};
struct que{
	struct plane queue[MAX];
	int front;
	int rear;
	}que1;
void enqueue(struct plane temp)
{
	if(((que1.rear+1)%MAX)==que1.front)
	{
		printf("Runway Full\n");
		return;
	}
	que1.rear=(que1.rear+1)%MAX;
	printf("Aeroplane enqueued for takeoff\n");
	strcpy(que1.queue[que1.rear].id,temp.id);
	strcpy(que1.queue[que1.rear].name,temp.name);
	if(que1.front==-1)
		que1.front=0;
}
struct plane dequeue()
{
	struct plane temp;
	if(que1.front==-1)
	{
		printf("Runway Empty\n");
		exit(0);
	}
	printf("Aeroplane took off\n");
	strcpy(temp.id,que1.queue[que1.front].id);
	strcpy(temp.name,que1.queue[que1.front].name);
	if(que1.front==que1.rear)
		que1.front=que1.rear=-1;
	else
		que1.front=(que1.front+1)%MAX;
	return temp;
}
void display()
{
	int i;
	if(que1.front==-1)
	{
		printf("Runway Empty\n");
		return;
	}
	printf("Condition of Runway:-\n");
	if(que1.front<=que1.rear)
	{
		for(i=que1.front;i<=que1.rear;i++)
		{
			printf("Aeroplane id: %s\n",que1.queue[i].id);
			printf("Aeroplane Name: %s\n\n",que1.queue[i].name);
		}
	}
	else
	{
		for(i=que1.rear;i<MAX;i++)
		{
			printf("Aeroplane id: %s\n",que1.queue[i].id);
			printf("Aeroplane Name: %s\n\n",que1.queue[i].name);
		}
		for(i=0;i<=que1.rear;i++)
		{
			printf("Aeroplane id: %s\n",que1.queue[i].id);
			printf("Aeroplane Name: %s\n\n",que1.queue[i].name);
		}
	}
}
void main()
{
	struct plane temp;
	que1.front=que1.rear=-1;
	char ch='y';
	int cho;
	while(ch=='y'||ch=='Y')
	{
		printf("\t\t\t\tRunway Menu\n");
		printf("\t\t\t\t1.Aeroplane Enqueuing\n");
		printf("\t\t\t\t2.Aeroplane Takeoff\n");
		printf("\t\t\t\t3.Condition of Runway\n");
		printf("\t\t\t\t4.Exit\n");
		printf("Enter your choice:");
		scanf("%d",&cho);
		switch(cho)
		{
			case 1: printf("Enter Aeroplane Name:");
				gets(temp.name);
				gets(temp.name);
				printf("Enter Aeroplane Id:");
				gets(temp.id);
				enqueue(temp);
				display();
				break;
			case 2: temp=dequeue();
				printf("Took off Aeroplane Information:\n");
				printf("Aeroplane id: %s\n",temp.id);
				printf("Aeroplane Name: %s\n\n",temp.name);
				break;
			case 3: display();
				break;
			case 4: exit(0);
				break;
			default:printf("Wrong choice\n");
				break;
		}
		printf("Do you want to continue(y for yes,n for no)?\n");
		scanf(" %c",&ch);
	}
}
