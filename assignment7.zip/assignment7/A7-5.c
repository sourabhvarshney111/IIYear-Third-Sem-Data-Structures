#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{
	char page[25];
	struct node* prev;
	struct node* next;
};

struct node* head = NULL;
struct node* current = NULL;

void Forward(){

	if(current == NULL){
		printf("There is no web-page");
	}
	else if(current->next == NULL){
		printf("This is last web-page");
	}
	else{
		current = current->next;
	}	
	printf("Done");
}

void Backward(){

	if(current == NULL){
		printf("There is no web-page");
	}
	else if(current->prev == NULL){
		printf("You are at first page");
	}
	else{
		current = current->prev;
	}
	printf("Done");
}

void NewWebPage(){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Web-page name :");	scanf("%s",temp->page);
	
	if(head == NULL)
	{
		temp -> prev = NULL;
		temp -> next = NULL;
		head = temp;
		current = head;
	}
	else{

		current->next = temp;
		temp->prev = current;
		temp->next = NULL;
		current = temp;

		/*struct node* ptr = head;  //Add at end
		while(ptr->next != NULL)
			ptr = ptr->next;

		ptr->next = temp;
		temp->prev = ptr;
		temp->next = NULL;*/
	}

}

void DisplayCurrent(){

	if(current != NULL){
		printf("\n%s",current->page);
	}
	else{
		printf("There is no web-page");
	}
}


void DisplayAll(){

	if(head == NULL){ 
		printf("There is no web-page");
	}
	else{
		struct node* ptr = head;
		while(ptr != NULL){
			printf(" %s", ptr->page);
			ptr = ptr->next;
		}
	}
}


void main()
{
	

	printf("\n********Web Borwser - Doubly Linear Link List ********");
	printf("\n1.Forward");
	printf("\n2.Backward");
	printf("\n3.New Web-page");
	printf("\n4.Display Current web-page");
	printf("\n5.Display all page");
	printf("\n6.EXIT");
	
	int choice;
	
	while(choice!=6){
		printf("\n\nYour Choice : ");	
		scanf("%d",&choice);

		switch(choice){
			case 1 : Forward();										break;
			case 2 : Backward();									break;
			case 3 : NewWebPage();									break;
			case 4 : DisplayCurrent();								break;
			case 5 : DisplayAll();									break;
			case 6 : printf("EXIT");								break;
			default : printf("Wrong Input");	
		}
	}
}