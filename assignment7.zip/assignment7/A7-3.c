#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{

	int data;
	struct node* link;
};

struct node* InsertAtBegin(struct node* head){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");		scanf("%d",&temp->data);

	temp -> link = head;
	head = temp;

	return head;
}

struct node* InsertAtEnd(struct node* head){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");	scanf("%d",&temp->data);

	temp -> link = NULL;
	
	if(head == NULL){
		head = temp;
		return head;
	}

	struct node* ptr = head;
	while(ptr->link != NULL)
		ptr = ptr -> link;

		ptr -> link = temp;

	return head;		
}

struct node* InsertAtIndex(struct node* head){

	int index;
	printf("\nEnter position : ");	scanf("%d",&index);

	if(index==1){
		head = InsertAtBegin(head);
		return head;
	}

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");		scanf("%d",&temp->data);

	struct node* ptr = head;
	int i;
	for(i=1;i<index-1;i++){
		ptr = ptr -> link;
		if(ptr == NULL){
			printf("Invalid position");
			return head;
		}
	}
	temp->link = ptr->link;
	ptr->link = temp;
	return head;
}

struct node* DeleteAtBegin(struct node* head){

	if(head == NULL){ printf("List is Empty"); return head; }

	struct node* ptr = head;
	head = head -> link;
	free(ptr);
	return head;
}

struct node* DeleteAtEnd(struct node* head){

	if(head == NULL){ printf("List is Empty"); return head; }

	struct node *ptr, *preptr;
	ptr = head;

	while(ptr->link != NULL){
		preptr = ptr;
		ptr = ptr -> link;
	}
	preptr -> link = NULL;
	free(ptr);

	return head;
}

struct node* DeleteAtIndex(struct node* head){

	int index;
	printf("Enter Location : ");	scanf("%d",&index);

	if(index==1){ head = DeleteAtBegin(head); return head; }
	
	struct node *ptr, *preptr;
	ptr = head;

	int i;
	for(i=1;i<index;i++){
		preptr = ptr;
		ptr = ptr -> link;
		if(ptr==NULL){ printf("Invalid Position"); return head;}
	} 
	preptr -> link = ptr -> link;
	free(ptr);

	return head;
}

struct node* SwappingNodes(struct node* head){

	if(head == NULL){
		printf("List is Empty"); 
		return head;
	}
	else if(head->link == NULL){
		printf("There is only one node");
		return head;
	}

	struct node *ptr,*nextptr,*preptr;

	ptr = head;
	preptr = NULL;
	head = head->link;
	
	while(ptr->link != NULL)
	{
		nextptr = ptr->link;						//pointing to next node
		if(preptr!= NULL)							//first time preptr is null so it has no link
			preptr->link = nextptr;					//preptr for after swapping creating link with last swappted	

		ptr->link = nextptr->link;					//swapping
		nextptr->link = ptr;

		preptr = ptr;								//saving last node
		if(ptr->link != NULL) 						//for even number case ptr->link is null so next stage going in infinite
			ptr = ptr ->link;						//going to next node
	}
	printf("Two consequtive nodes swapped");
	return head;
}

void display(struct node* head){

	if(head == NULL){ printf("List is Empty"); }
	
	struct node* temp = head;
	while(temp != NULL){

		printf(" %d",temp->data);
		temp = temp -> link;
	}	
}


void main(){

	struct node *head = NULL;

	printf("\n******** Link List ********");
	printf("\n1. Insertion at Begining");
	printf("\n2.Insertion at End");
	printf("\n3.Insertion at Index");
	printf("\n4.Delete at Begining");
	printf("\n5.Delete at End");
	printf("\n6.Delete at Index");
	printf("\n7.Swapping two consequtive nodes");
	printf("\n8.Display");
	printf("\n9.EXIT");
	
	int choice;
	
	while(choice!=9){
		printf("\n\nYour Choice : ");	
		scanf("%d",&choice);

		switch(choice){
			case 1 : head = InsertAtBegin(head);		break;
			case 2 : head = InsertAtEnd(head);			break;
			case 3 : head = InsertAtIndex(head);		break;
			case 4 : head = DeleteAtBegin(head);		break;
			case 5 : head = DeleteAtEnd(head);			break;
			case 6 : head = DeleteAtIndex(head);		break;
			case 7 : head = SwappingNodes(head);		break;
			case 8 : display(head);						break;
			case 9 : printf("EXIT");					break;
			default : printf("Wrong Input");	
		}
	}
}