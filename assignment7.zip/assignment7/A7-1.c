#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{
	int data;
	struct node* prev;
	struct node* next;
};

struct node* InsertAtBegin(struct node* head){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");	scanf("%d",&temp->data);

	if(head==NULL)
		temp->next = NULL;
	else
		temp->next = head;
	
	temp->prev = NULL;
	if(head!=NULL)head->prev=temp;	
	head = temp;
	return head;
}

struct node* InsertAtEnd(struct node* head){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");	scanf("%d",&temp->data);
	
	if(head == NULL)
	{
		temp -> prev = NULL;
		temp -> next = NULL;
		head = temp;
		return head;
	}

	struct node* ptr = head;
	while(ptr->next != NULL)
		ptr = ptr->next;

	ptr->next = temp;
	temp->prev = ptr;
	temp->next = NULL;
	return head;
}

struct node* InsertAtIndex(struct node* head){

	int index;
	printf("\nEnter position : ");	scanf("%d",&index);

	if(index==1){
		head = InsertAtBegin(head);
		return head; 
	}

	struct node* temp = (struct node*)malloc(sizeof(struct node));

	printf("\nEnter Data :");	scanf("%d",&temp->data);
	
	struct node* ptr = head;
	int i;
	for(i=1;i<index-1;i++){
		ptr = ptr->next;
		if(ptr == NULL){
			printf("Invalid Index");
			return head;
		}
	}

	temp->prev = ptr;
	temp->next = ptr->next;
	if(ptr->next != NULL)ptr->next->prev = temp;
	ptr->next = temp;
	return head;
}

struct node* DeleteAtBegin(struct node* head){

	if(head == NULL){ printf("List is Empty"); return head; }

	struct node* ptr = head;
	head = head->next;
	if(ptr->next != NULL)head->prev = NULL;
	free(ptr);
	return head;
}

struct node* DeleteAtEnd(struct node* head){

	if(head == NULL){printf("List is Empty"); return head; }

	struct node *ptr = head;

	while(ptr->next != NULL)
		ptr = ptr->next;
	
	ptr->prev->next = NULL;
	free(ptr);

	return head;
} 

struct node* DeleteAtIndex(struct node* head){

	int index;
	printf("\nEnter position :");	scanf("%d",&index);

	if(index == 1){ head = DeleteAtBegin(head); return head;}

	struct node *ptr,*preptr;
	ptr = head;

	int i;
	for(i=1;i<index;i++){
		ptr = ptr -> next;
		if(ptr==NULL){printf("Invalid index"); return head;}
	}

	ptr->prev->next = ptr->next;
	if(ptr->next != NULL)ptr->next->prev = ptr->prev;
	
	free(ptr);
	return head;
	
}


void Display(struct node* head){

	if(head == NULL){ printf("List is Empty"); return;}

	struct node* ptr = head;
	while(ptr != NULL){
		printf(" %d", ptr->data);
		ptr = ptr->next;
	}
}

struct node* Reverse(struct node* head){

	struct node* current = head;
	struct node *temp;
	while(current->next!=NULL)
	{
		temp = current->next;
		current->next = current->prev;
		current->prev = temp;

		current = temp;
	}
	head = current;

	temp = current->next;
	current->next = current->prev;
	current->prev = temp;

	printf("Linked list is reversed");
	return head;
}

void main()
{
	struct node *head = NULL;

	printf("\n********Doubly Linear Link List ********");
	printf("\n1.Insertion at Begining");
	printf("\n2.Insertion at End");
	printf("\n3.Insertion at Index");
	printf("\n4.Delete at Begining");
	printf("\n5.Delete at End");
	printf("\n6.Delete at Index");
	printf("\n7.Reverse");
	printf("\n8.Display");
	printf("\n9.EXIT");
	
	int choice;
	
	while(choice!=9){
		printf("\n\nYour Choice : ");	
		scanf("%d",&choice);

		switch(choice){
			case 1 : head = InsertAtBegin(head);		break;
			case 2 : head = InsertAtEnd(head);			break;
			case 3 : head = InsertAtIndex(head);		break;
			case 4 : head = DeleteAtBegin(head);		break;
			case 5 : head = DeleteAtEnd(head);			break;
			case 6 : head = DeleteAtIndex(head);		break;
			case 7 : head = Reverse(head);				break;
			case 8 : Display(head);						break;
			case 9 : printf("EXIT");					break;
			default : printf("Wrong Input");	
		}
	}
}