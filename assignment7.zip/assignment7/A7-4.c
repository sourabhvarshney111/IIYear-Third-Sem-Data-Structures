#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{

	int data;
	struct node* link;
};

struct node* InsertAtBegin(struct node* head){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");	scanf("%d",&temp->data);

	if(head==NULL){
		temp->link = temp;
		head = temp;
		return head;
	}
	
	struct node* ptr = head;
	while(ptr->link != head)
		ptr = ptr->link;

	ptr->link = temp;
	temp->link = head;
	head = temp;
	return head;
}

struct node* InsertAtEnd(struct node* head){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");	scanf("%d",&temp->data);

	if(head == NULL){
		head = temp;
		temp->link = head;
		return head;
	}

	struct node* ptr = head;
	while(ptr->link != head)
		ptr = ptr -> link;

	ptr -> link = temp;
	temp -> link = head;
	return head;		
}

struct node* InsertAtIndex(struct node* head){

	int index,check;
	printf("\nEnter position : ");	scanf("%d",&index);

	if(index==1){
		head = InsertAtBegin(head);
		return head;
	}

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");	scanf("%d",&temp->data);

	struct node* ptr = head;
	int i;
	for(i=1;i<index-1;i++){
		ptr = ptr -> link;
		if(ptr == head){
			printf("Invalid position");
			return head;
		}
	}
	temp->link = ptr->link;
	ptr->link = temp;
	return head;
}

struct node* DeleteAtBegin(struct node* head){

	if(head == NULL){ printf("List is Empty"); return head; }

	struct node *ptr;
	ptr = head;
	while(ptr->link!=head)
		ptr = ptr->link;

	ptr->link = head->link;
	head = head->link;
	free(ptr);
	return head;
}

struct node* DeleteAtEnd(struct node* head){

	if(head == NULL){ printf("List is Empty"); return head; }

	struct node *ptr, *preptr;
	ptr = head;

	while(ptr->link != head){
		preptr = ptr;
		ptr = ptr -> link;
	}
	preptr -> link = head;
	free(ptr);

	return head;
}

struct node* DeleteAtIndex(struct node* head){

	int index;
	printf("Enter Location : ");	scanf("%d",&index);

	if(index==1){ head = DeleteAtBegin(head); return head; }
	
	struct node *ptr, *preptr;
	ptr = head;

	int i;
	for(i=1;i<index;i++){
		preptr = ptr;
		ptr = ptr -> link;
		if(ptr==head){ printf("Invalid Position"); return head;}
	} 
	preptr -> link = ptr -> link;
	free(ptr);

	return head;
}

void display(struct node* head,struct node* head2){

	struct node* temp;

	if(head == NULL){ 
		printf("List1 is Empty"); 
	}
	else{
		temp = head;
		printf("List1 : ");
		while(temp->link != head){

			printf(" %d",temp->data);
			temp = temp -> link;
		}	
		printf(" %d",temp->data);
	}

	if(head2 == NULL){ 
		printf("\nList2 is Empty"); 
	}
	else{
		temp = head2;
		printf("\nList2 : ");
		while(temp->link != head2){

		printf(" %d",temp->data);
		temp = temp -> link;
		}	
		printf(" %d",temp->data);
	}

}

struct node* DivideIntoTwo(struct node* head){

	struct node* head2 = NULL;

	if(head == NULL){
		printf("List is Empty");
		return head2;
	}
	else if(head->link == head){
		printf("List has only one node");
		return head2;
	}

	struct node *ptr,*preptr,*lastptr;

	lastptr = head;
	int i=1;

	while(lastptr->link!=head){
		lastptr=lastptr->link;
		i++;
	}

	ptr = head;
	int j=0;
	for(j=0 ; j < (i+1)/2 ; j++){
		preptr = ptr;
		ptr = ptr->link;
	}

	preptr->link = head;
	head2 = ptr;
	lastptr->link = ptr;

	printf("List is Divided into two equal parts");
	return head2;
}

void main(){

	struct node *head = NULL;
	struct node *head2 = NULL;

	printf("\n******** Link List ********");
	printf("\n1. Insertion at Begining");
	printf("\n2.Insertion at End");
	printf("\n3.Insertion at Index");
	printf("\n4.Delete at Begining");
	printf("\n5.Delete at End");
	printf("\n6.Delete at Index");
	printf("\n7.Display");
	printf("\n8.Divide into two Parts");
	printf("\n9.EXIT");
	
	int choice;
	
	while(choice!=9){
		printf("\n\nYour Choice : ");	
		scanf("%d",&choice);

		switch(choice){
			case 1 : head = InsertAtBegin(head);		break;
			case 2 : head = InsertAtEnd(head);			break;
			case 3 : head = InsertAtIndex(head);		break;
			case 4 : head = DeleteAtBegin(head);		break;
			case 5 : head = DeleteAtEnd(head);			break;
			case 6 : head = DeleteAtIndex(head);		break;
			case 7 : display(head,head2);				break;
			case 8 : head2 = DivideIntoTwo(head);		break;
			case 9 : printf("EXIT");					break;
			default : printf("Wrong Input");	
		}
	}
}