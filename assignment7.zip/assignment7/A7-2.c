#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{

	int data;
	struct node* link;
};

struct node* Insert(struct node* head){

	struct node* temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter Data :");		scanf("%d",&temp->data);

	if(head == NULL){
	temp -> link = NULL;
	head = temp;
	return head;
	}

	struct node *ptr,*preptr;
	ptr = head;

	if(ptr->data > temp->data){
		temp->link = head;
		head = temp;
		return head;
	}

	while(ptr->data <= temp->data){

		preptr=ptr;
		ptr = ptr->link;
		if(ptr == NULL){
			preptr->link = temp;
			temp->link = NULL;
			return head;
		}
	}
	temp->link = ptr;
	preptr->link = temp;
	return head;
}

struct node* DeleteAtBegin(struct node* head){

	if(head == NULL){ printf("List is Empty"); return head; }

	struct node* ptr = head;
	head = head -> link;
	free(ptr);
	return head;
}


struct node* DeleteAtEnd(struct node* head){

	if(head == NULL){ printf("List is Empty"); return head; }

	struct node *ptr, *preptr;
	ptr = head;

	while(ptr->link != NULL){
		preptr = ptr;
		ptr = ptr -> link;
	}
	preptr -> link = NULL;
	free(ptr);

	return head;
}

struct node* DeleteAtIndex(struct node* head){

	int index;
	printf("Enter Location : ");	scanf("%d",&index);

	if(index==1){ head = DeleteAtBegin(head); return head; }
	
	struct node *ptr, *preptr;
	ptr = head;

	int i;
	for(i=1;i<index;i++){
		preptr = ptr;
		ptr = ptr -> link;
		if(ptr==NULL){ printf("Invalid Position"); return head;}
	} 
	preptr -> link = ptr -> link;
	free(ptr);

	return head;
}

struct node* DeleteDuplicate(struct node* head){

	struct node *ptr,*nextptr;
	ptr = head;

	while(ptr->link != NULL){

		nextptr = ptr->link;

		if(ptr->data == nextptr->data){
			ptr->link = nextptr->link;
			free(nextptr);
		}
		else
			ptr=ptr->link;
	}
	printf("Duplicates are removed");
	return head;
}



void display(struct node* head){

	if(head == NULL){ printf("List is Empty"); }
	
	struct node* temp = head;
	while(temp != NULL){

		printf(" %d",temp->data);
		temp = temp -> link;
	}	
}


void main(){

	struct node *head = NULL;

	printf("\n******** Sorted Link List ********");
	printf("\n1.Insertion");
	printf("\n2.Delete at Begining");
	printf("\n3.Delete at End");
	printf("\n4.Delete at Index");
	printf("\n5.Delete Duplicate");
	printf("\n6.Display");
	printf("\n7.EXIT");
	
	int choice;
	
	while(choice!=7){
		printf("\n\nYour Choice : ");	
		scanf("%d",&choice);

		switch(choice){
			case 1 : head = Insert(head);				break;
			case 2 : head = DeleteAtBegin(head);		break;
			case 3 : head = DeleteAtEnd(head);			break;
			case 4 : head = DeleteAtIndex(head);		break;
			case 5 : head = DeleteDuplicate(head);		break;
			case 6 : display(head);						break;
			case 7 : printf("EXIT");					break;
			default : printf("Wrong Input");	
		}
	}
}